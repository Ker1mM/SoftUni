namespace Species
{
    using System;
    using System.Collections.Generic;

    class SpeciesProgram
    {
        static void Main()
        {
            var answers = new List<int>();
            string[] answersStrings = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            for (int j = 0; j < answersStrings.Length - 1; j++)
            {
                answers.Add(int.Parse(answersStrings[j]));
            }

            int n = answers.Count;
            answers.Sort();

            int t = 0, i = 0;

            while (i < n)
            {
                int x = answers[i] + 1, c = 0;
                while (i < n && answers[i] == x - 1)
                {
                    c++;
                    i++;
                }

                while (c % x != 0)
                {
                    c++;
                }

                t += c;
            }

            Console.WriteLine(t);
        }
    }
}
