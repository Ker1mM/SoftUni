﻿namespace FestivalManager.Entities.Instruments
{
    public class Microphone : Instrument
    {
        public Microphone() : base()
        {

        }
        protected override int RepairAmount => 80;
    }
}
