﻿namespace Travel.Entities.Items
{
	public class Screw : Item
	{
		public Screw()
			: base(1)
		{
		}
	}
}