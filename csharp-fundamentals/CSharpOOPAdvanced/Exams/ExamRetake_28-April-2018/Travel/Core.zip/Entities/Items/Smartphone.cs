﻿namespace Travel.Entities.Items
{
	public class Smartphone : Item
	{
		public Smartphone()
			: base(1000)
		{
		}
	}
}