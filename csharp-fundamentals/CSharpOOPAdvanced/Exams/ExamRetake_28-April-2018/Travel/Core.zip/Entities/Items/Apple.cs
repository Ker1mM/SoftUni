﻿namespace Travel.Entities.Items
{
	public class Apple : Item
	{
		public Apple()
			: base(1)
		{
		}
	}
}