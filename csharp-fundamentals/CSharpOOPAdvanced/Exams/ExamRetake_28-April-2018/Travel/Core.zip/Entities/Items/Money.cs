﻿namespace Travel.Entities.Items
{
	public class Money : Item
	{
		public Money()
			: base(5)
		{
		}
	}
}