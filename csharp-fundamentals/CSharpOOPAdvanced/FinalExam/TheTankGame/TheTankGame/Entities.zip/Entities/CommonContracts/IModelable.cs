﻿namespace TheTankGame.Entities.CommonContracts
{
    public interface IModelable
    {
        string Model { get; }
    }
}