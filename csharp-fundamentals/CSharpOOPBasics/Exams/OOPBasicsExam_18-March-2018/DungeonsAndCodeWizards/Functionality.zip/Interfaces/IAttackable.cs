﻿using DungeonsAndCodeWizards.Models.Characters;

namespace DungeonsAndCodeWizards.Interfaces
{
    public interface IAttackable
    {
        void Attack(Character character);
    }
}
