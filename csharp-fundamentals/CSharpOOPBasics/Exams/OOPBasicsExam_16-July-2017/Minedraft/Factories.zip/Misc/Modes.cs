﻿public enum Modes
{
    Full,
    Half,
    Energy
}
