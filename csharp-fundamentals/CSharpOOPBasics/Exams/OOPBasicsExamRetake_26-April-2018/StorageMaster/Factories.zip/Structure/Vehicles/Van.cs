﻿namespace StorageMaster.Structure.Vehicles
{
    public class Van : Vehicle
    {
        private const int vanCapacity = 2;

        public Van() : base(vanCapacity)
        {

        }
    }
}
